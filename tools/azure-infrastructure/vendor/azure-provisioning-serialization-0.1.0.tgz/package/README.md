# `@azure/provisioning-serialization`

`@azure/provisioning-serialization` defines a Bicep-aligned JSON format. Each serialized document contains a `infras` array, and each entry represents a Bicep file with a `fileName`, a `targetScope`, and declarations grouped by category such as `resources`, `outputs`, or `variables`.

## Design rules

Expression and value nodes keep a `kind`.

File-level declaration buckets do not need `kind` tags because the enclosing key already identifies what they are. For example, entries under `resources` are always resource declarations, and entries under `outputs` are always outputs.

Named declarations also carry a `bicepIdentifier` field. This is the identifier that should be emitted in Bicep source, and it allows lowering to preserve or synthesize names without overloading the JSON object key.

The remaining node naming follows official Bicep terminology first, and Bicep's internal `Bicep.Core.Syntax` names second. For example:

- `ProgramSyntax` -> `program`
- `ResourceDeclarationSyntax` -> `resource-declaration`
- `FunctionCallSyntax` -> `function-call`
- `PropertyAccessSyntax` -> `property-access`

Values are boxed as nodes, but native JSON payloads are used where they fit:

- strings stay strings
- booleans stay booleans
- `null` stays `null`
- integers are decimal strings to preserve Bicep `int` fidelity

Object literals stay explicit nodes, but their members live in a plain JSON map under `value`.

Interpolated strings are represented as expression trees such as `function-call` with `target: "concat"` in the first milestone.

## Generating serializations from `@azure/provisioning-core`

This package can project the current core authoring objects into the serialization AST:

```ts
import { resourceGroup, stack } from "@azure/provisioning-core";
import { serialize } from "@azure/provisioning-serialization";

const infra = stack({
  name: "infras",
  targetScope: "subscription",
});

resourceGroup(infra, {
  name: "rg-demo",
  location: "eastus",
});

const serialization = serialize([infra]);
```

`@azure/provisioning-storage` and other RP packages stay serialization-agnostic. They only produce core handles and expressions; this package is responsible for translating those shapes into the JSON AST.

Top-level authoring can also compose infrastructure by nesting stacks. File layout stays an internal lowering concern of serialization rather than part of the authoring API.

## File layout contract

Every resource must have its own file, with the following exceptions:

- Subscription-scoped resources, which must be collected into a single subscription scoped bicep.
- Sub-resources, which must be defined in the same bicep as its parent resource.

The subscription-scoped bicep file, when present, must contain `module` declarations for all other bicep files. This module declaration must provide all necessary parameters and pass the appropriate `scope`.

Bicep files for non-subscription-scoped resources must be resource group scoped. Such resources must not have a defined "scope" property.

When an infra has parameters, and a declaration within a bicep file references that parameter, the bicep file must declare that parameter. When the declarations within the bicep file do not reference a parameter, it must not be declared.

The subscription-scoped bicep file, when present, must contain outputs from all other bicep files.

## High-level mapping

File fields:

- file name -> `infras[n].fileName`
- `targetScope = ...` -> `infras[n].targetScope`
- `metadata foo = ...` -> `infras[n].metadata.foo`
- `param foo ...` -> `infras[n].parameters.foo`
- `var foo = ...` -> `infras[n].variables.foo`
- `output foo ...` -> `infras[n].outputs.foo`
- `type Foo = ...` -> `infras[n].types.Foo`
- `func foo(...) ... => ...` -> `infras[n].functions.foo`
- `resource foo 'Type@ApiVersion' = ...` -> `infras[n].resources.foo`
- `module foo './mod.bicep' = ...` -> `infras[n].modules.foo`
- `assert foo = ...` -> `infras[n].asserts.foo`
- `import ... from ...` -> `infras[n].compileTimeImports[]`
- `import 'az@1.0.0'` -> `infras[n].namespaceImports[]`

Expressions:

- identifiers -> `identifier`
- function calls -> `function-call`
- instance function calls -> `instance-function-call`
- property access -> `property-access`
- array access -> `array-access`
- nested resource access -> `resource-access`
- contextual values imported from `az` -> `contextual-variable`
- unary/binary/ternary operators -> `unary-operation`, `binary-operation`, `ternary-operation`
- loops -> `for-expression`
- conditions -> `if-condition`
- lambdas -> `lambda`
- spreads -> `spread-expression`
- non-null assertion -> `non-null-assertion`

Types:

- primitive types -> `primitive-type`
- type references -> `type-reference`
- literal types -> `string-type-literal`, `integer-type-literal`, `boolean-type-literal`, `null-type-literal`
- arrays/tuples -> `array-type`, `tuple-type`
- objects -> `object-type`
- unions -> `union-type`
- nullable/non-nullable -> `nullable-type`, `non-nullable-type`
- parameterized type forms -> `parameterized-type-instantiation`

## Worked example

### Bicep

```bicep
targetScope = 'subscription'

param location string = 'eastus'
param isEnabled bool = true

var storageName = concat('demo', uniqueString(subscription().subscriptionId))

resource sa 'Microsoft.Storage/storageAccounts@2024-01-01' = {
  name: storageName
  location: location
  kind: 'StorageV2'
  sku: {
    name: 'Standard_LRS'
  }
}
```

### JSON

```json
{
  "infras": [
    {
      "fileName": "infra.bicep",
      "targetScope": "subscription",
      "parameters": {
        "location": {
          "valueType": {
            "kind": "primitive-type",
            "name": "string"
          },
          "defaultValue": {
            "kind": "string",
            "value": "eastus"
          }
        }
      },
      "variables": {
        "storageName": {
          "value": {
            "kind": "function-call",
            "target": "concat",
            "args": [
              {
                "kind": "string",
                "value": "demo"
              },
              {
                "kind": "function-call",
                "target": "uniqueString",
                "args": [
                  {
                    "kind": "contextual-variable",
                    "context": "subscription",
                    "property": "subscriptionId"
                  }
                ]
              }
            ]
          }
        }
      },
      "resources": {
        "sa": {
          "type": "Microsoft.Storage/storageAccounts",
          "apiVersion": "2024-01-01",
          "existing": false,
          "value": {
            "kind": "object",
            "value": {
              "name": {
                "kind": "identifier",
                "id": "storageName"
              },
              "location": {
                "kind": "identifier",
                "id": "location"
              },
              "kind": {
                "kind": "string",
                "value": "StorageV2"
              },
              "sku": {
                "kind": "object",
                "value": {
                  "name": {
                    "kind": "string",
                    "value": "Standard_LRS"
                  }
                }
              }
            }
          }
        }
      }
    }
  ]
}
```
