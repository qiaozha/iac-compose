# `@azure/provisioning-bicep`

`@azure/provisioning-bicep` renders the JSON AST produced by `@azure/provisioning-serialization` into Bicep source files.

## Usage

```ts
import { serialize } from "@azure/provisioning-serialization";
import { renderBicepFiles } from "@azure/provisioning-bicep";

const serialization = serialize(infra);
const files = renderBicepFiles(serialization);

for (const file of files) {
  console.log(file.path);
  console.log(file.contents);
}
```

Each returned item has:

- `path`: the output file path, currently taken from `fileName`
- `contents`: the rendered Bicep text

## Generate parameter files

```ts
import {
  bicepRef,
  createBicepParameterFile,
  renderBicepFile,
} from "@azure/provisioning-bicep";
import { fn } from "@azure/provisioning-core";

const env = bicepRef<string>("env");
const parameterFile = createBicepParameterFile("main.bicepparam", {
  using: "./main.bicep",
  variables: {
    env: fn.readEnvironmentVariable("AZURE_ENV_NAME", "dev"),
  },
  parameters: {
    resourceGroupName: fn.concat("rg-app-", env),
  },
});

const rendered = renderBicepFile(parameterFile);
```
