# `@azure/provisioning-core`

Azure Provisioning is a JavaScript library for defining infrastructure in Azure.

In practice, most applications use `@azure/provisioning-core` together with one or more resource provider packages.

## Overall usage patterns

The typical flow is:

1. Create a root deployment container with `stack(...)`.
2. Create a resource group and use that as the container for most resources.
3. Call resource factories from provider packages such as `storageAccount(...)` and `keyVault(...)`.
4. Use returned handles to reference values and create child resources.

Here is a representative example using storage and Key Vault:

```ts
import { az, fn, resourceGroup, stack } from "@azure/provisioning-core";
import { keyVault, keyVaultSecret } from "@azure/provisioning-keyvault";
import { storageAccount } from "@azure/provisioning-storage";

const infra = stack({
  name: "infra",
  targetScope: "subscription",
});

const rg = resourceGroup(infra, {
  name: "rg-demo",
  location: "eastus",
});

const storage = storageAccount(rg, {
  name: fn
    .concat("demo", fn.uniqueString(az.subscription.subscriptionId))
    .take(24)
    .toLower(),
});

const vault = keyVault(rg, {
  name: fn
    .concat("kv", fn.uniqueString(az.subscription.subscriptionId))
    .take(24)
    .toLower(),
  tenantId: "00000000-0000-0000-0000-000000000000",
  enabledForTemplateDeployment: true,
});

const storageNameSecret = keyVaultSecret(vault, {
  name: "storage-account-name",
  value: storage.name,
});
```

A few patterns are worth keeping in mind:

- Resource groups are regular handles, but they also work as deployment containers for other resources.
- When you create a resource inside a resource-group container, you usually do not need to repeat the resource group name or location.
- Resource factories return handles. Those handles are what you pass to child resources or use when wiring values together.
- `fn` and `az` let you build symbolic Azure expressions without dropping down to raw strings.

## Composing infrastructure

Higher-level building blocks are just normal functions that create several resources.

Use `stack(container)` inside those helpers when you want a distinct logical container for a composition.

```ts
import { fn, stack, type DeploymentContainer } from "@azure/provisioning-core";
import { keyVault } from "@azure/provisioning-keyvault";
import { storageAccount } from "@azure/provisioning-storage";

export function appStorage(container: DeploymentContainer, name: string) {
  const component = stack(container);

  const vault = keyVault(component, {
    name: fn.concat(name, "-kv").take(24).toLower(),
    tenantId: "00000000-0000-0000-0000-000000000000",
  });

  const storage = storageAccount(component, {
    name: fn.concat(name, "sa").take(24).toLower(),
  });

  return { container: component, vault, storage };
}
```

## API listing

This section focuses on how each API is used rather than showing exact TypeScript signatures.

### `stack`

Creates a deployment container.

Use it in two ways:

- `stack(...)` for a root stack
- `stack(container)` for a nested container inside a larger composition

```ts
import { stack } from "@azure/provisioning-core";

const infra = stack({
  name: "infra",
  targetScope: "subscription",
});

const nested = stack(infra, {
  name: "database",
});
```

### `resourceGroup`

Declares a resource group and returns a handle that can also be used as a deployment container.

```ts
import { resourceGroup, stack } from "@azure/provisioning-core";

const infra = stack({
  name: "infra",
  targetScope: "subscription",
});

const rg = resourceGroup(infra, {
  name: "rg-demo",
  location: "eastus",
});
```

Using the resource group as the container is the normal pattern for resource-level deployments:

```ts
import { storageAccount } from "@azure/provisioning-storage";

const storage = storageAccount(rg, {
  name: "demostorageacct",
});
```

### `az`

Provides deployment context values such as subscription properties.

This is commonly used for name generation and other derived expressions.

```ts
import { az, fn } from "@azure/provisioning-core";

const storageName = fn
  .concat("demo", fn.uniqueString(az.subscription.subscriptionId))
  .take(24)
  .toLower();
```

### `fn`

Builds Azure expressions in a typed, composable way.

Use it for string construction, symbolic IDs, and other expression-based values.

```ts
import { az, fn } from "@azure/provisioning-core";

const uniqueName = fn
  .concat("orders", fn.uniqueString(az.subscription.subscriptionId))
  .take(24)
  .toLower();
```

### `resource`

Advanced API for declaring a resource directly from core.

Most application code will use provider packages instead, but this is useful when prototyping a resource or building a new provider package.

```ts
import { resource, stack } from "@azure/provisioning-core";

const infra = stack({
  name: "infra",
  targetScope: "subscription",
});

const myResource = resource(infra, {
  name: "example",
  type: "Contoso.Example/widgets",
  apiVersion: "2024-01-01",
});
```

### `childResourceHandle`

Advanced API for declaring a child resource under another resource handle.

```ts
import { childResourceHandle } from "@azure/provisioning-core";

const child = childResourceHandle(resource, {
  name: "default",
  type: "Contoso.Example/widgets/configurations",
  apiVersion: "2024-01-01",
});
```

## Working with provider packages

`@azure/provisioning-core` defines the common authoring model.

Provider packages build on top of it:

- `@azure/provisioning-storage` adds `storageAccount(...)`
- `@azure/provisioning-keyvault` adds `keyVault(...)` and `keyVaultSecret(...)`
- other packages can follow the same pattern

The normal user experience is:

- use core to define deployment containers and expressions
- use provider packages to declare resources
- use returned handles to wire resources together
